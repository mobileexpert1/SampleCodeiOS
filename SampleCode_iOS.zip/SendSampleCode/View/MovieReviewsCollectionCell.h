//
//  MovieReviewsCollectionCell.h
//
//  Created by Lakhwinder Singh on 18/08/15.
//  Copyright (c) 2014 CSSoft. All rights reserved.
//

#import "AbstractNestingCell.h"
@protocol MovieReviewCellDelegate;

/**
 Cell with movie reviews collection
 */

@interface MovieReviewsCollectionCell : AbstractNestingCell

@property (weak, nonatomic) id <MovieReviewCellDelegate> delegate;

@end

////////////////////////////////////////////////////////////////////////////////

/**
 Cell with a single movie review
 */

@interface ReviewCell : AbstractCell

@property (weak, nonatomic) id <MovieReviewCellDelegate> delegate;

@end

@protocol MovieReviewCellDelegate <NSObject>

- (void)invalidateLayout;

@end


