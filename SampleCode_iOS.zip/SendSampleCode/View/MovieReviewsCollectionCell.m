//
//  MovieReviewsCollectionCell.m
//
//  Created by Lakhwinder Singh on 18/08/15.
//  Copyright (c) 2014 CSSoft. All rights reserved.
//

#import "MovieReviewsCollectionCell.h"
#import "CinemaObjectDetailsData.h"
#import "Movie.h"
#import "Review.h"
#import "CollectionLayout.h"
#import "CellHeaderLabel.h"
#import <LibOften/LibOften.h>

@interface MovieReviewsCollectionCell () <MovieReviewCellDelegate>

@property (strong, nonatomic, readonly) UIPageControl *pageControl;

@property (strong, nonatomic, readonly) UILabel *totalLabel;

@end

@implementation MovieReviewsCollectionCell

+ (AbstractCollectionLayout *)extendedLayout {
    return [ReviewsWideNestedLayout new];
}

+ (Class <AbstractCell>)cellClass {
    return [ReviewCell class];
}

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        self.headerLabel.text = @"Reviews";
        [self.contentView addSubviews:@[self.pageControl, self.totalLabel]];
    } return self;
}

#pragma mark properties

@synthesize pageControl = _pageControl, totalLabel = _totalLabel;

- (UIPageControl *)pageControl {
    if (!_pageControl) {
        _pageControl = [UIPageControl new];
        _pageControl.hidden = iPad();
        DefineWeakSelf;
        _pageControl.valueChangedBlock = ^{
            NSIndexPath *indexPath = [NSIndexPath indexPathForItem:weakSelf.pageControl.currentPage inSection:0];
            [weakSelf.collectionView scrollToItemAtIndexPath:indexPath atScrollPosition:UICollectionViewScrollPositionCenteredHorizontally animated:YES];
        };
    } return _pageControl;
}

- (UILabel *)totalLabel {
    if (!_totalLabel) {
        _totalLabel = [UILabel new];
        _totalLabel.textAlignment = NSTextAlignmentCenter;
        _totalLabel.textColor = [UIColor lightGrayColor];
        _totalLabel.font = [UIFont systemFontOfSize:14.0 weight:UIFontWeightLight];
    } return _totalLabel;
}

#pragma mark collection view

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    ReviewCell *cell = [ReviewCell typecastWithAssertion:[super collectionView:collectionView cellForItemAtIndexPath:indexPath]];
    cell.delegate = self;
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView willDisplayCell:(UICollectionViewCell *)cell forItemAtIndexPath:(NSIndexPath *)indexPath {
    self.pageControl.currentPage = indexPath.item;
}

// FIXME: cell sizing should be moved to superclass

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    AbstractCell *cell = [self offScreenCellForItemAtIndexPath:indexPath]; // Note: we used visible cells here before, but it brokes rotation handling
    return [cell cellSize];
}

- (AbstractCell *)visibleCellForItemAtIndexPath:(NSIndexPath *)indexPath {
    return [AbstractCell typecastWithAssertion:[self.collectionView cellForItemAtIndexPath:indexPath]];
}

- (AbstractCell *)offScreenCellForItemAtIndexPath:(NSIndexPath *)indexPath {
    AbstractCell *offScreenCell = [self.cellClass new];
    [offScreenCell updateWithModel:self.items[indexPath.item]];
    return offScreenCell;
}

#pragma mark layout

- (void)setupAutolayoutConstraints {
    NSDictionary *subviews = @{@"header":self.headerLabel, @"collection":self.collectionView, @"page":self.pageControl, @"total":self.totalLabel};
    self.contentView.layoutMargins = UIEdgeInsetsMake(4.0, 11.0, 4.0, 11.0);
    [self.contentView addVisualConstraints:@[@"H:|-[header]-|", @"H:|-[collection]-|", @"H:|-44-[page]-44-|", @"H:|-[total]-|"] forSubviews:subviews];
    [self.contentView addVisualConstraints:@[@"V:|-[header]-8-[collection][page(==22)][total]->=4-|"] forSubviews:subviews];
    [self.collectionView addConstraint:self.collectionHeightConstraint];
}

- (void)setItems:(NSArray *)items {
    [super setItems:items];
    [self updateCollectionHeightConstraint];
}

- (void)updateCollectionHeightConstraint {
    [self layoutIfNeeded];
    self.collectionHeightConstraint.constant = [self.collectionView.visibleCells.firstObject cellSize].height;
}

- (void)invalidateLayout {
    [self.extendedLayout invalidateLayout];
    [self updateCollectionHeightConstraint];
    [self.delegate invalidateLayout];
}

#pragma mark model

+ (NSArray *)itemsFromModel:(id)model {
    return [MovieDetailsData typecastWithAssertion:model].detailedMovie.reviews;
}

- (void)updateWithModel:(id)model {
    [super updateWithModel:model];
    NSUInteger numberOfReviews = self.items.count;
    self.pageControl.numberOfPages = numberOfReviews;
    self.totalLabel.text = [NSString stringWithFormat:@"%lu %@", (unsigned long)numberOfReviews, numberOfReviews == 1 ? @"review" : @"reviews"];
}

@end

////////////////////////////////////////////////////////////////////////////////

@interface ReviewCell ()

@property (strong, nonatomic, readonly) UILabel *snippetLabel;

@property (strong, nonatomic, readonly) UILabel *authorLabel;

@property (strong, nonatomic, readonly) UIButton *chevronButton;

@property (assign, nonatomic, getter=isExpanded) BOOL expanded;

@end

@implementation ReviewCell

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self.contentView addSubviews:@[self.snippetLabel, self.authorLabel, self.chevronButton]];
    } return self;
}

#pragma mark properties

@synthesize snippetLabel = _snippetLabel, authorLabel = _authorLabel, chevronButton = _chevronButton;

- (UILabel *)snippetLabel {
    if (!_snippetLabel) {
        _snippetLabel = [UILabel new];
        _snippetLabel.numberOfLines = 4;
        _snippetLabel.preferredMaxLayoutWidth = [self.class cellSize].width;
        _snippetLabel.font = [UIFont systemFontOfSize:17.0 weight:UIFontWeightLight];
        _snippetLabel.textColor = [UIColor whiteColor];
    } return _snippetLabel;
}

- (UILabel *)authorLabel {
    if (!_authorLabel) {
        _authorLabel = [UILabel new];
        _authorLabel.font = [UIFont systemFontOfSize:16.0 weight:UIFontWeightLight];
        _authorLabel.textColor = [UIColor lightGrayColor];
    } return _authorLabel;
}

- (UIButton *)chevronButton {
    if (!_chevronButton) {
        _chevronButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _chevronButton.image = [UIImage imageNamed:@"chevron-down"];
        _chevronButton.contentEdgeInsets = UIEdgeInsetsMake(0.0, 22.0, 0.0, 22.0);
        DefineWeakSelf;
        _chevronButton.touchUpInsideBlock = ^{
            weakSelf.expanded = !weakSelf.isExpanded;
        };
    } return _chevronButton;
}

- (void)setExpanded:(BOOL)expanded {
    _expanded = expanded;
    [self animateWithDuration:0.25 constraintsAnimations:^{
        self.snippetLabel.numberOfLines = expanded ? 0 : 4;
        self.chevronButton.transform = expanded ? CGAffineTransformMakeRotation(M_PI) : CGAffineTransformIdentity;
        [self.delegate invalidateLayout];
    }];
}

#pragma mark layout

+ (CGSize)cellSize {
    return [[ReviewsWideNestedLayout new] itemSize];
}

- (CGSize)cellSize {
    [self updateConstraintsIfNeeded]; // If updateConstraints wasn't called yet
    return [self.contentView systemLayoutSizeFittingSize:UILayoutFittingCompressedSize];
}

- (void)setupAutolayoutConstraints {
    NSDictionary *subviews = @{@"snippet":self.snippetLabel, @"author":self.authorLabel, @"chevron":self.chevronButton};
    [self.contentView addConstraintForWidth:[self.class cellSize].width];
    [self.contentView addVisualConstraints:@[@"H:|[snippet]|", @"H:|[author]|", @"H:[chevron]|", @"V:|-[snippet][author]-|", @"V:[snippet][chevron]"] forSubviews:subviews];
}

#pragma mark model

- (void)updateWithModel:(id)model {
    Review *review = [Review typecastWithAssertion:model];
    self.snippetLabel.text = [review.content stringByRemovingNewLineCharacters];
    self.authorLabel.text = review.author;
}

@end


