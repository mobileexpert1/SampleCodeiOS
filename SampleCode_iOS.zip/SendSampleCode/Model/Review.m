//
//  Review.m
//
//  Created by Lakhwinder Singh on 07/12/14.
//  Copyright (c) 2014 CSSoft. All rights reserved.
//

#import "Review.h"

@implementation Review

+ (Review *)reviewWithId:(NSString *)id author:(NSString *)author content:(NSString *)content path:(NSString *)path {
    Review *review = [Review new];
    review.id = id;
    review.author = author;
    review.content = content;
    review.url = [NSURL URLWithString:path];
    return review;
}

@synthesize id, author, content, url;

// Custom description
- (NSString *)description {
    return [NSString stringWithFormat:@"%@ %@", [super description], url.absoluteString];
}

@end


