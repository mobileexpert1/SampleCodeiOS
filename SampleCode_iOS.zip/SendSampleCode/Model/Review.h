//
//  Review.h
//
//  Created by Lakhwinder Singh on 07/12/14.
//  Copyright (c) 2014 CSSoft. All rights reserved.
//

@import Foundation;

/**
 Model of tmdb.org movie review
 */

@interface Review : NSObject
//! Returns review object with given data
+ (Review *)reviewWithId:(NSString *)id author:(NSString *)author content:(NSString *)content path:(NSString *)path;
/// Review id
@property (strong, nonatomic) NSString *id;
/// Review author
@property (strong, nonatomic) NSString *author;
/// Review text
@property (strong, nonatomic) NSString *content;
/// Review URL
@property (strong, nonatomic) NSURL *url;
@end


