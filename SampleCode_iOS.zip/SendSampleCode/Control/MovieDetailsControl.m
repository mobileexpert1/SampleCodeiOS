//
//  MovieDetailsControl.m
//
//  Created by Lakhwinder Singh on 07/08/15.
//  Copyright (c) 2014 CSSoft. All rights reserved.
//

#import "MovieDetailsControl.h"
#import "CinemaObjectDetailsData.h"
#import "MediaIndex.h"
#import "InfoCell.h"
#import "GenresCollectionCell.h"
#import "MovieShowtimesButtonCell.h"
#import "MovieWatchButtonCell.h"
#import "TheatersCollectionCell.h"
#import "ExpandableTextCell.h"
#import "TrailersCollectionCell.h"
#import "MediaCollectionCell.h"
#import "BackdropsCollectionCell.h"
#import "ActorsCollectionCell.h"
#import "AdvertisementCell.h"
#import "MovieReviewsCollectionCell.h"
#import "MoviesCollectionCell.h"
#import "ActivityIndicatorCell.h"
#import "ProductsCollectionCell.h"
#import "PosterCell.h"
#import "DetailsBackgroundView.h"
#import "MovieStore.h"
#import "ItunesStore.h"
#import "UserStore.h"
#import <PromiseKit/PromiseKit.h>
#import <LibOften/LibOften.h>

@interface MovieDetailsControl () <ExpandableTextCellDelegate, MovieReviewCellDelegate>

@property (strong, nonatomic, readonly) DetailsBackgroundView *detailsBackgroundView;

@property (strong, nonatomic, readonly) MovieDetailsData *movieDetailsData;

@end

@implementation MovieDetailsControl

+ (instancetype)controlForMovie:(LightMovie *)movie {
    MovieDetailsControl *control = [self new];
    control.movieDetailsData.lightMovie = movie;
    return control;
}

+ (NSArray *)allCellClasses {
    NSArray *availableClasses = @[
             [MovieInfoCell class],
             [MovieShowtimesButtonCell class],
             [MovieWatchButtonCell class],
             [MovieGenresCollectionCell class],
             [TheatersCollectionCell class],
             [MovieSynopsisCell class],
             [MovieTrailersCollectionCell class],
             [MediaCollectionCell class],
             [ProductsCollectionCell class],
             [MovieCastCollectionCell class],
             [AdvertisementCell class],
             [MovieCrewCollectionCell class],
             [MovieBackdropsCollectionCell class],
             [MovieReviewsCollectionCell class],
             [SimilarMoviesCollectionCell class],
             [ActivityIndicatorCell class],
             ];
    if (iPhone()) {
        return availableClasses;
    } else {
        NSMutableArray *ipadClasses = [availableClasses mutableCopy];
        [ipadClasses removeObjectsInArray:@[[MovieShowtimesButtonCell class], [MovieWatchButtonCell class]]];
        return [ipadClasses copy];
    }
}

+ (NSArray *)allSupplementaryViewClasses {
    return iPhone() ? @[] : @[[MoviePosterCell class], [MovieShowtimesButtonCell class], [MovieWatchButtonCell class]];
}

#pragma mark state transitioning

- (void)viewDidLoad {
    [super viewDidLoad];
    [self requestDetailsData];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self modelDidUpdated]; // moved from viewDidLoad to refresh ads on recurring appearances
}

- (void)contentOffsetDidChanged {
    [super contentOffsetDidChanged];
    [self.detailsBackgroundView contentOffsetDidChangedTo:self.collectionView.relativeContentOffset];
}

#pragma mark properties

@synthesize detailsBackgroundView = _detailsBackgroundView;

- (DetailsBackgroundView *)detailsBackgroundView {
    if (!_detailsBackgroundView) {
        _detailsBackgroundView = [[DetailsBackgroundView alloc] initWithFrame:self.collectionView.bounds];
        [_detailsBackgroundView updateWithModel:self.movieDetailsData];
    } return _detailsBackgroundView;
}

- (MovieDetailsData *)movieDetailsData {
    if (!self.model) {
        self.model = [MovieDetailsData new];
    } return self.model;
}

#pragma mark collection view

- (void)setupCollectionView {
    [super setupCollectionView];
    self.collectionView.backgroundView = self.detailsBackgroundView;
}

- (AbstractCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    AbstractCell *cell = [super collectionView:collectionView cellForItemAtIndexPath:indexPath];
    if ([cell isKindOfClass:[MovieSynopsisCell class]]) {
        [[MovieSynopsisCell typecastWithAssertion:cell] setDelegate:self];
    } else if ([cell isKindOfClass:[MovieReviewsCollectionCell class]]) {
        [[MovieReviewsCollectionCell typecastWithAssertion:cell] setDelegate:self];
    }
    return cell;
}


#pragma mark actions

- (void)modelDidUpdated {
    [super modelDidUpdated];
    [self.detailsBackgroundView updateWithModel:self.movieDetailsData];
    self.parentViewController.title = self.movieDetailsData.detailedMovie.title ?: self.movieDetailsData.lightMovie.title; // In case of awakening from NSUserActivity
}

- (void)requestDetailsData {
    [self requestMovieDetails];
    [self requestRemoteMovieAndRelevantMediaObjects];
    [self requestRelevantItunesProducts];
    [self requestShowtimes];
}

- (void)requestMovieDetails {
    [[MovieStore shared] requestMovieDetailsById:self.movieDetailsData.lightMovie.tmdb withCompletion:^(Movie *detailedMovie){
        self.movieDetailsData.detailedMovie = detailedMovie ?: [Movie nullObject];
        [self modelDidUpdated];
    }];
}

#define MEDIA_OBJECTS_LIMIT 20

- (void)requestRemoteMovieAndRelevantMediaObjects {
    firstly.then(^{
        return [[MovieStore shared] promiseGetRemoteObjectForLocalMovie:self.movieDetailsData.lightMovie];
    }).then(^(LightMovie *remoteMovie){
        self.movieDetailsData.remoteMovie = remoteMovie;
        [self modelDidUpdated];
        MediaIndexQuery *query = [[MediaIndexQuery queryForIndexesOfObjectsRelatedToMovie:remoteMovie] addLimit:MEDIA_OBJECTS_LIMIT];
        return [[MovieStore shared] promiseGetMediaObjectsWithMediaIndexQuery:query];
    }).then(^(NSArray *mediaObjects){
        self.movieDetailsData.mediaObjects = mediaObjects;
        [self modelDidUpdated];
    }).catch(^(NSError *error){
        if (!self.movieDetailsData.remoteMovie)
            self.movieDetailsData.remoteMovie = [Movie nullObject];
        self.movieDetailsData.mediaObjects = @[];
        [self modelDidUpdated];
    });
}

- (void)requestRelevantItunesProducts {
    [[ItunesStore shared] requestItunesProductsForMovie:self.movieDetailsData.lightMovie completion:^(NSArray *itunesProducts){
        self.movieDetailsData.itunesProducts = itunesProducts ?: @[];
        [self modelDidUpdated];
    }];
}

- (void)requestShowtimes {
    NSArray *theatersFav = [[UserStore shared] favoriteTheaters];
    if (theatersFav.count) {
        [[MovieStore shared] requestShowtimesForMovie:(Movie *)self.movieDetailsData.lightMovie inFavTheaters:theatersFav withCompletion:^(NSArray *ts) { // FIXME: dangerous typecast
            self.movieDetailsData.showtimesFavTheaters = ts ?: @[];
            [self modelDidUpdated];
        }];
    }
    else {
        self.movieDetailsData.showtimesFavTheaters = @[];
        [self modelDidUpdated];
    }
}

- (void)invalidateLayout {
    [self.collectionViewLayout invalidateLayout];
}

- (NSString *)description {
    return [NSString stringWithFormat:@"%@ %@", [super description], self.movieDetailsData.lightMovie];
}

@end


