//
//  MovieDetailsControl.h
//
//  Created by Lakhwinder Singh on 07/08/15.
//  Copyright (c) 2014 CSSoft. All rights reserved.
//

#import "AbstractDetailsControl.h"
@class LightMovie;

/**
 View controller of movie details collection view
 */

@interface MovieDetailsControl : AbstractDetailsControl

+ (instancetype)controlForMovie:(LightMovie *)movie;

@end


