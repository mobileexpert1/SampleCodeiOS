//
//  TmdbStore.m
//
//  Created by Lakhwinder Singh on 03/12/14.
//  Copyright (c) 2014 CSSoft. All rights reserved.
//

#import "TmdbStore.h"
#import "Movie.h"
#import "Show.h"
#import "Genre.h"
#import "Poster.h"
#import "Backdrop.h"
#import "Video.h"
#import "Actor.h"
#import "Review.h"
#import "ErrorStore.h"
#import <LibOften/LibOften.h>

#if TARGET_OS_IOS //Replace target check with ios to use same class in tv OS
    #import "SpotlightStore.h"
#endif

#define TMDB_BASE_API_URL @"https://api.tmdb.org/3"
#define TMDB_API_KEY @"**************************"
#define TMDB_KEY_RESULTS @"results"
#define TMDB_MOVIE_TYPES @[@"now_playing", @"upcoming", @"popular", @"top_rated"]
#define TMDB_MOVIE_DETAILS_APPEND @"append_to_response=trailers,credits,similar,images,releases,reviews,videos"
#define TMDB_ACTOR_DETAILS_APPEND @"append_to_response=combined_credits,images,tagged_images"
#define USA_COUNTRY_CODE @"US"

@implementation TmdbStore

#pragma mark Singleton

+ (instancetype)shared {
    static dispatch_once_t predicate;
    static TmdbStore *shared;
    dispatch_once(&predicate, ^{
        shared = [[super allocWithZone:nil] init];
    }); return shared;
}

//! Singleton (designated allocator)
+ (id)allocWithZone:(struct _NSZone *)zone {
    return [self shared];
}

@synthesize skipGenres;

#pragma mark Movie requests

- (void)requestMovieListOfType:(MovieListType)type page:(NSUInteger)page withCompletion:(void(^)(NSArray *movies))completion {
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/movie/%@?api_key=%@&page=%lu", TMDB_BASE_API_URL, TMDB_MOVIE_TYPES[type], TMDB_API_KEY, (unsigned long)page]]; // Construct URL
    [NSURLSession jsonFromURL:url completion:^(id json){ // Make a request
        NSArray *movies = [self isListJsonOK:json] ? [self moviesArray:type == MovieListTypeNowPlaying ? YES : NO andJSON:json[TMDB_KEY_RESULTS]] : nil; // Get the result
        dispatch_async_main(^{
            completion(movies);
        }); // Execute completion block
    }];
}

- (void)requestMovieListForGenre:(NSString *)tmdbId page:(NSUInteger)page withCompletion:(void(^)(NSArray *movies))completion {
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/genre/%@/movies?api_key=%@&page=%lu", TMDB_BASE_API_URL, tmdbId, TMDB_API_KEY, (unsigned long)page]]; // Construct URL
    [NSURLSession jsonFromURL:url completion:^(id json){
        NSArray *movies = [self isListJsonOK:json] ? [self moviesArray:NO andJSON:json[TMDB_KEY_RESULTS]] : nil; // Get the result
        dispatch_async_main(^{
            completion(movies);
        }); // Execute completion block
    }];
}

- (void)requestSearchForMovies:(NSString *)query andPage:(NSInteger)page withCompletion:(void(^)(NSArray *movies))completion {
    NSString *escaped = [query stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]]; // Escape search query
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/search/movie?api_key=%@&query=%@&page=%lu", TMDB_BASE_API_URL, TMDB_API_KEY, escaped, (long)page]]; // Construct URL
    [NSURLSession jsonFromURL:url completion:^(id json){
        NSArray *movies = [self isListJsonOK:json] ? [self moviesArray:NO andJSON:json[TMDB_KEY_RESULTS]] : nil; // Get the result
        dispatch_async_main(^{
            completion(movies);
        }); // Execute completion block
    }];
}

- (void)requestSearchForShows:(NSString *)query andPage:(NSInteger)page withCompletion:(void(^)(NSArray *shows))completion {
    NSString *escaped = [query stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]]; // Escape search query
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/search/tv?api_key=%@&query=%@&page=%lu", TMDB_BASE_API_URL, TMDB_API_KEY, escaped, (long)page]]; // Construct URL
    [NSURLSession jsonFromURL:url completion:^(id json){
        NSArray *shows = [self isListJsonOK:json] ? [self showsArray:json[TMDB_KEY_RESULTS]] : nil; // Get the result
        dispatch_async_main(^{
            completion(shows);
        }); // Execute completion block
    }];
}

- (void)requestMovieDetailsById:(NSNumber *)tmdbId withCompletion:(void(^)(Movie *movie))completion {
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/movie/%@?%@&api_key=%@", TMDB_BASE_API_URL, tmdbId.stringValue, TMDB_MOVIE_DETAILS_APPEND, TMDB_API_KEY]]; // Construct URL
    [NSURLSession jsonFromURL:url completion:^(id json){ // Make a request
        Movie *movie = [self isMovieJsonOK:json] ? [self movieFromJSON:json] : nil;
        dispatch_async_main(^{
            completion(movie);
        });
    }];
}

- (void)requestShowDetailsById:(NSNumber *)tmdbId withCompletion:(void (^)(Show *))completion {
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/tv/%@?%@&api_key=%@", TMDB_BASE_API_URL, tmdbId.stringValue, TMDB_MOVIE_DETAILS_APPEND, TMDB_API_KEY]]; // Construct URL
    [NSURLSession jsonFromURL:url completion:^(id json){ // Make a request
        Show *show = [self isShowJsonOK:json] ? [self showFromJSON:json] : nil;
        dispatch_async_main(^{
            completion(show);
        });
    }];
}

- (void)requestShowSeasonDetailsByShow:(Show *)show withCompletion:(void (^)(Show *))completion {
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/tv/%@/season/%@?%@&api_key=%@", TMDB_BASE_API_URL, show.tmdb.stringValue,show.seasonNumber, TMDB_MOVIE_DETAILS_APPEND, TMDB_API_KEY]]; // Construct URL
    [NSURLSession jsonFromURL:url completion:^(id json){ // Make a request
        Show *showNew = [self isShowJsonOK:json] ? [self seasonFromJSON:json parentShow:show] : nil;
        dispatch_async_main(^{
            completion(showNew);
        });
    }];
}

- (void)requestShowEpisodeDetailsBySeason:(Show *)season withCompletion:(void (^)(Show *))completion {
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/tv/%@/season/%@/episode/%@?%@&api_key=%@", TMDB_BASE_API_URL, season.tmdb.stringValue, season.seasonNumber, season.episodeNumber, TMDB_MOVIE_DETAILS_APPEND, TMDB_API_KEY]]; // Construct URL
    [NSURLSession jsonFromURL:url completion:^(id json){ // Make a request
        Show *showNew = [self isShowJsonOK:json] ? [self episodesFromJSON:json parentSeason:season] : nil;
        dispatch_async_main(^{
            completion(showNew);
        });
    }];
}

#pragma mark Actors requests

- (void)requestSearchForActors:(NSString *)query andPage:(NSInteger)page withCompletion:(void(^)(NSArray *))completion {
    NSString *escaped = [query stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]]; // Escape search query
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/search/person?api_key=%@&query=%@&page=%lu", TMDB_BASE_API_URL, TMDB_API_KEY, escaped, (long)page]]; // Construct URL
    [NSURLSession jsonFromURL:url completion:^(id json){
        NSArray *actors = [self isListJsonOK:json] ? [self actorsArrayFromJSON:json[TMDB_KEY_RESULTS]] : nil; // Get the result
        dispatch_async_main(^{
            completion(actors);
        }); // Execute completion block
    }];
}

- (void)requestPopularActorsPage:(NSInteger)page withCompletion:(void(^)(NSArray *))completion {
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/person/popular?api_key=%@&page=%lu", TMDB_BASE_API_URL, TMDB_API_KEY, (long)page]]; // Construct URL
    [NSURLSession jsonFromURL:url completion:^(id json){ // Make a request
        NSArray *actors = [self isListJsonOK:json] ? [self actorsArrayFromJSON:json[TMDB_KEY_RESULTS]] : nil;
        dispatch_async_main(^{
            completion(actors);
        });
    }];
}

- (void)requestActorDetailsById:(NSNumber *)tmdbId withCompletion:(void(^)(Actor *))completion {
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/person/%@?%@&api_key=%@", TMDB_BASE_API_URL, tmdbId.stringValue, TMDB_ACTOR_DETAILS_APPEND, TMDB_API_KEY]]; // Construct URL
    [NSURLSession jsonFromURL:url completion:^(id json){ // Make a request
        Actor *actor = [self isActorJsonOK:json] ? [self actorFromJSON:json] : nil;
        dispatch_async_main(^{
            completion(actor);
        });
    }];
}

#pragma mark JSON parsers

//! Returns Movie object from JSON
- (Movie *)movieFromJSON:(id)json {
    if (![self isMovieJsonOK:json])
        return nil;
    Movie *tmdb = [Movie new];
    tmdb.tmdb = json[@"id"];
    tmdb.title = json[@"title"];
    tmdb.backdrop = [Backdrop backdropWithPath:json[@"backdrop_path"]];
    tmdb.poster = [Poster posterWithPath:json[@"poster_path"]];
    tmdb.backdropUrl = json[@"backdrop_path"];
    tmdb.posterUrl = json[@"poster_path"];
    tmdb.releaseDate = [self releaseDateFromJSON:json];
    tmdb.tagline = json[@"tagline"];
    tmdb.overview = json[@"overview"];
    tmdb.voteAverage = [json[@"vote_average"] floatValue];
    tmdb.voteCount = [json[@"vote_count"] intValue];
    tmdb.runtime = [json[@"runtime"] floatValue];
    tmdb.revenue = json[@"revenue"];
    tmdb.budget = json[@"budget"];
    tmdb.genres = [self genresArrayFromJSON:json];
    tmdb.backdrops = [self backdropsArrayFromMovieJSON:json];
    tmdb.posters = [self postersArrayFromJSON:json];
    tmdb.trailers = [self trailersArrayFromJSON:json];
    tmdb.cast = [self castArrayFromJSON:json];
    tmdb.crew = [self crewArrayFromJSON:json];
    tmdb.reviews = [self reviewsArrayFromJSON:json];
    tmdb.character = json[@"character"];
    tmdb.rating = [self ratingFromJSON:json];
    tmdb.popularity = json[@"popularity"];
    tmdb.similar = [self moviesArray:NO andJSON:json[@"similar"][@"results"]];
    return tmdb;
}

//! Returns tv show object from JSON
- (Show *)showFromJSON:(id)json {
    if (![self isShowJsonOK:json])
        return nil;
    Show *tmdb = [Show new];
    tmdb.showType = ShowTypeTV;
    tmdb.tmdb = json[@"id"];
    tmdb.title = json[@"name"];
    tmdb.backdrop = [Backdrop backdropWithPath:json[@"backdrop_path"]];
    tmdb.poster = [Poster posterWithPath:json[@"poster_path"]];
    tmdb.backdropUrl = json[@"backdrop_path"];
    tmdb.posterUrl = json[@"poster_path"];
    tmdb.releaseDate = [NSDate dateFromString:json[@"first_air_date"] withFormat:@"yyyy-MM-dd"];
    tmdb.tagline = json[@"status"];
    tmdb.trailers = [self videosArrayFromJSON:json];
    tmdb.overview = json[@"overview"];
    tmdb.voteAverage = [json[@"vote_average"] floatValue];
    tmdb.voteCount = [json[@"vote_count"] intValue];
    tmdb.runtime = [json[@"episode_run_time"][0] floatValue];
    tmdb.genres = [self genresArrayFromJSON:json];
    tmdb.backdrops = [self backdropsArrayFromMovieJSON:json];
    tmdb.posters = [self postersArrayFromJSON:json];
    tmdb.cast = [self castArrayFromJSON:json];
    tmdb.crew = [self crewArrayFromJSON:json];
    tmdb.reviews = [self reviewsArrayFromJSON:json];
    tmdb.popularity = json[@"popularity"];
    tmdb.numberOfSeasons = json[@"number_of_seasons"];
    tmdb.numberOfEpisodes = json[@"number_of_episodes"];
    tmdb.similar = [self showsArray:json[@"similar"][@"results"]];
    tmdb.seasons = [self showSeasonsArray:json[@"seasons"] show:tmdb];
    return tmdb;
}

//! Returns season tv show with object from JSON
- (Show *)seasonFromJSON:(id)json parentShow:(Show *)show {
    Show *showSeason = [Show new];
    showSeason.showType = ShowTypeSeason;
    //Get old information
    showSeason.tmdb = show.tmdb;
    showSeason.backdrop = show.backdrop;
    showSeason.backdropUrl = show.backdropUrl;
    showSeason.showtitle = show.showtitle;
    showSeason.numberOfEpisodes = show.numberOfEpisodes;
    //Get new data
    if (json[@"episode_count"]) showSeason.numberOfEpisodes = json[@"episode_count"];
    if (!json[@"name"]) showSeason.title = [NSString stringWithFormat:@"Season %@",json[@"season_number"]];
    else showSeason.title = json[@"name"];
    showSeason.overview = json[@"overview"];
    showSeason.seasonNumber = json[@"season_number"];
    showSeason.releaseDate = [NSDate dateFromString:json[@"air_date"] withFormat:@"yyyy-MM-dd"];
    showSeason.poster = [Poster posterWithPath:json[@"poster_path"]];
    showSeason.posterUrl = json[@"poster_path"];
    showSeason.trailers = [self videosArrayFromJSON:json];
    showSeason.cast = [self castArrayFromJSON:json];
    showSeason.crew = [self crewArrayFromJSON:json];
    showSeason.backdrops = [self backdropsArrayFromMovieJSON:json];
    showSeason.posters = [self postersArrayFromJSON:json];
    showSeason.episodes = [self showSeasonEpisodeArray:json[@"episodes"] season:showSeason];
    showSeason.rating = @"TV-PG";
    return showSeason;
}


//! Returns episode of season tv show with object from JSON
- (Show *)episodesFromJSON:(id)json parentSeason:(Show *)show {
    Show *seasonEpisodes = [Show new];
    seasonEpisodes.showType = ShowTypeEpisode;
    //Get old information
    seasonEpisodes.tmdb = show.tmdb;
    seasonEpisodes.genres = show.genres;
    seasonEpisodes.tagline = show.tagline;
    seasonEpisodes.popularity = show.popularity;
    seasonEpisodes.backdrop = show.backdrop;
    seasonEpisodes.backdropUrl = show.backdropUrl;
    seasonEpisodes.showtitle = show.showtitle;
    seasonEpisodes.seasonTitle = show.seasonTitle;
    
    //Get new data
    seasonEpisodes.title = json[@"name"];
    seasonEpisodes.overview = json[@"overview"];
    seasonEpisodes.seasonNumber = json[@"season_number"];
    seasonEpisodes.episodeNumber = json[@"episode_number"];
    seasonEpisodes.releaseDate = [NSDate dateFromString:json[@"air_date"] withFormat:@"yyyy-MM-dd"];
    seasonEpisodes.poster = [Poster posterWithPath:json[@"still_path"]];
    seasonEpisodes.posterUrl = json[@"still_path"];
    seasonEpisodes.voteAverage = [json[@"vote_average"] floatValue];
    seasonEpisodes.voteCount = [json[@"vote_count"] intValue];
    seasonEpisodes.trailers = [self videosArrayFromJSON:json];
    seasonEpisodes.cast = [self castArrayFromJSON:json];
    seasonEpisodes.crew = [self crewArrayFromJSON:json];
    seasonEpisodes.backdrops = [self backdropsArrayFromMovieJSON:json];
    seasonEpisodes.posters = [self postersArrayFromJSON:json];
    
    return seasonEpisodes;
}

//! Returns actor object from actor JSON
- (Actor *)actorFromJSON:(id)json {
    if (![self isActorJsonOK:json])
        return nil;
    Actor *actor = [Actor new];
    actor.tmdb = json[@"id"];
    actor.name = json[@"name"];
    actor.imdb = json[@"imdb_id"];
    actor.portrait = [Portrait portraitWithPath:json[@"profile_path"]];
    actor.birthday = [NSDate dateFromString:json[@"birthday"] withFormat:@"yyyy-MM-dd"];
    actor.deathday = [NSDate dateFromString:json[@"deathday"] withFormat:@"yyyy-MM-dd"];
    actor.placeOfBirth = json[@"place_of_birth"];
    actor.biography = json[@"biography"];
    actor.backdrops = [self backdropArrayFromActorJSON:json];
    actor.moviesKnownFor = [self moviesSortedByReleaseDate:[self moviesArrayFromJSON:json[@"known_for"] whereKey:@"media_type" equalTo:@"movie"]];
    actor.moviesPlayed = [self moviesSortedByReleaseDate:[self moviesArrayFromJSON:json[@"combined_credits"][@"cast"] whereKey:@"media_type" equalTo:@"movie"]];
    actor.moviesDirected = [self moviesSortedByReleaseDate:[self moviesArrayFromJSON:json[@"combined_credits"][@"crew"] whereKey:@"department" equalTo:@"Directing"]];
    actor.moviesWrote = [self moviesSortedByReleaseDate:[self moviesArrayFromJSON:json[@"combined_credits"][@"crew"] whereKey:@"department" equalTo:@"Writing"]];
    actor.moviesProduced = [self moviesSortedByReleaseDate:[self moviesArrayFromJSON:json[@"combined_credits"][@"crew"] whereKey:@"department" equalTo:@"Production"]];
    actor.alsoKnownAs = json[@"also_known_as"];
    actor.portraits = [self portraitsFromActorJson:json];
    return actor;
}

- (NSArray *)moviesSortedByReleaseDate:(NSArray *)arrayToSort {
    NSArray *sortedByDueDate = [arrayToSort sortedArrayUsingComparator:^NSComparisonResult(Movie *movie1, Movie *movie2) {
        return [movie2.releaseDate compare:movie1.releaseDate];
    }];
    return sortedByDueDate;
}

//! Returns release date (if possible - for local country) from tmdb.org movie JSON
- (NSDate *)releaseDateFromJSON:(id)json {
    NSDate *localReleaseDate;
    NSDate *usaReleaseDate;
    NSString *localCountryCode = [[NSLocale currentLocale] objectForKey:NSLocaleCountryCode];
    for (NSDictionary *item in json[@"releases"][@"countries"]) {
        NSString *itemCountryCode = item[@"iso_3166_1"];
        NSDate *itemReleaseDate = [NSDate dateFromString:item[@"release_date"] withFormat:@"yyyy-MM-dd"];
        if ([itemCountryCode isEqualToString:localCountryCode])
            localReleaseDate = itemReleaseDate;
        if ([itemCountryCode isEqualToString:USA_COUNTRY_CODE])
            usaReleaseDate = itemReleaseDate;
    }
    NSDate *globalReleaseDate = [NSDate dateFromString:json[@"release_date"] withFormat:@"yyyy-MM-dd"];
    return localReleaseDate ?: globalReleaseDate ?: usaReleaseDate;
}

//! Returns rating (if possible - for local country) from tmdb.org movie JSON
- (NSString *)ratingFromJSON:(id)json {
    NSString *localRating;
    NSString *usRating;
    if (json[@"releases"]) { // If JSON have worldwide releases
        NSString *localCountry = [[NSLocale currentLocale] objectForKey:NSLocaleCountryCode]; // Get current locale
        for (NSDictionary *item in json[@"releases"][@"countries"]) { // Cycle available countries
            NSString *currentCountry = item[@"iso_3166_1"];
            if ([currentCountry isEqualToString:localCountry])
                localRating = item[@"certification"];
            if ([currentCountry isEqualToString:@"US"])
                usRating = item[@"certification"];
        }
    }
    return localRating.length > 0 ? localRating : usRating.length > 0 ? usRating : nil;
}

//! Returns genres array from tmdb.org movie JSON
- (NSArray *)genresArrayFromJSON:(id)json {
    NSMutableArray *genres = [NSMutableArray new];
    for (NSDictionary *item in json[@"genres"])
        if (![skipGenres containsObject:item[@"name"]] && item[@"id"] && item[@"name"])
            [genres addObject:[[Genre alloc] initWithTmdbId:item[@"id"] name:item[@"name"] imageURL:nil]];
    return genres.count > 0 ? genres : nil;
}

//! Returns array of backdrops from movie JSON
- (NSArray *)backdropsArrayFromMovieJSON:(id)json {
    NSMutableArray *backdrops = [NSMutableArray new];
    for (NSDictionary *item in json[@"images"][@"backdrops"])
        if ([(NSString *)item[@"file_path"] length] > 0)
            [backdrops addObject:[Backdrop backdropWithPath:item[@"file_path"]]];
    for (NSDictionary *item in json[@"images"][@"stills"]) //For Tv show episode images
        if ([(NSString *)item[@"file_path"] length] > 0)
            [backdrops addObject:[Backdrop backdropWithPath:item[@"file_path"]]];
    return backdrops.count > 0 ? backdrops : nil;
}

//! Returns array of posters from movie JSON
- (NSArray *)postersArrayFromJSON:(id)json {
    NSMutableArray *posters = [NSMutableArray new];
    for (NSDictionary *item in json[@"images"][@"posters"])
        if ([(NSString *)item[@"file_path"] length] > 0)
            [posters addObject:[Poster posterWithPath:item[@"file_path"]]];
    return posters.count > 0 ? posters : nil;
}

//! Returns array of trailers from movie JSON
- (NSArray *)trailersArrayFromJSON:(id)json {
    NSMutableArray *trailers = [NSMutableArray new];
    for (NSDictionary *item in json[@"trailers"][@"youtube"])
        if ([(NSString *)item[@"source"] length] > 0)
            [trailers addObject:[Video createWithTitle:item[@"name"] youTubeId:item[@"source"]]];
    return trailers.count > 0 ? trailers : nil;
}

//! Returns array of videos from tv show JSON
- (NSArray *)videosArrayFromJSON:(id)json {
    NSMutableArray *trailers = [NSMutableArray new];
    for (NSDictionary *item in json[@"videos"][@"results"])
        if ([(NSString *)item[@"key"] length] > 0)
            [trailers addObject:[Video createWithTitle:item[@"name"] youTubeId:item[@"key"]]];
    return trailers.count > 0 ? trailers : nil;
}

//! Returns array of cast from movie JSON
- (NSMutableArray *)castArrayFromJSON:(id)json {
    NSMutableArray *cast = [NSMutableArray new];
    for (NSDictionary *item in json[@"credits"][@"cast"]) {
        Actor *actor = [Actor actorWithId:item[@"id"] character:item[@"character"] name:item[@"name"] path:item[@"profile_path"]];
        if (actor)
            [cast addObject:actor];
    }
    return cast.count > 0 ? cast : nil;
}

//! Returns array of cast from movie JSON
- (NSMutableArray *)crewArrayFromJSON:(id)json {
    NSMutableArray *cast = [NSMutableArray new];
    for (NSDictionary *item in json[@"credits"][@"crew"])
        [cast addObject:[Actor actorWithId:item[@"id"] character:item[@"job"] name:item[@"name"] path:item[@"profile_path"]]];
    return cast.count > 0 ? cast : nil;
}

//! Returns array of reviews from movie JSON
- (NSArray *)reviewsArrayFromJSON:(id)json {
    NSMutableArray *reviews = [NSMutableArray new];
    for (NSDictionary *item in json[@"reviews"][@"results"])
        [reviews addObject:[Review reviewWithId:item[@"id"] author:item[@"author"] content:item[@"content"] path:item[@"url"]]];
    return reviews.count > 0 ? reviews : nil;
}

//! Returns array of tv show seasons from JSON
- (NSArray *)showSeasonEpisodeArray:(id)json season:(Show *)show {
    NSMutableArray *episodes = [NSMutableArray new];
    for (NSDictionary *item in json) {
        Show *episodeGet = [self episodesFromJSON:item parentSeason:show];
        //To Skip upcoming movies coming in theaters tab.
        if (episodeGet)
            [episodes addObject:episodeGet];
    }
    return episodes.count > 0 ? [episodes reversedArray] : nil;
}

//! Returns array of tv show seasons from JSON
- (NSArray *)showSeasonsArray:(id)json show:(Show *)show {
    NSMutableArray *shows = [NSMutableArray new];
    for (NSDictionary *item in json) {
        Show *showGet = [self seasonFromJSON:item parentShow:show];
        //To Skip upcoming movies coming in theaters tab.
        if (showGet)
            [shows addObject:showGet];
    }
    return shows.count > 0 ? [shows reversedArray] : nil;
}

//! Returns array of tv shows from JSON
- (NSArray *)showsArray:(id)json {
    NSMutableArray *shows = [NSMutableArray new];
    for (NSDictionary *item in json) {
        Show *show = [self showFromJSON:item];
        //To Skip upcoming movies coming in theaters tab.
        if (show)
            [shows addObject:show];
    }
#if TARGET_OS_IOS //Replace target check with ios to use same class in tv OS
    [[SpotlightStore shared] addShows:shows];
#endif
    return shows.count > 0 ? shows : nil;
}

//! Returns array of movies from JSON
- (NSArray *)moviesArray:(BOOL)skipFututres andJSON:(id)json {
    NSMutableArray *movies = [NSMutableArray new];
    for (NSDictionary *item in json) {
        Movie *movie = [self movieFromJSON:item];
        //To Skip upcoming movies coming in theaters tab.
        if (skipFututres) {
            NSComparisonResult result = [[NSDate date] compare:movie.releaseDate];
            if (result == NSOrderedAscending)
                continue;
        }
        if (movie)
            [movies addObject:movie];
    }
#if TARGET_OS_IOS //Replace target check with ios to use same class in tv OS
    [[SpotlightStore shared] addMovies:movies];
#endif
    return movies.count > 0 ? movies : nil;
}

//! Returns array by finding dictionary from JSON
- (NSArray *)moviesArrayFromJSON:(id)json whereKey:(NSString *)strKey equalTo:(NSString *)strValue {
    NSMutableArray *movies = [NSMutableArray new];
    for (NSDictionary *item in json)
        if ([item[strKey] isEqualToString:strValue] && [self isMovieJsonOK:item])
            [movies addObject:[self movieFromJSON:item]];
    return movies.count > 0 ? movies : nil;
}

//! Returns array of actors from JSON
- (NSArray *)actorsArrayFromJSON:(id)json {
    NSMutableArray *actors = [NSMutableArray new];
    for (NSDictionary *item in json) {
        Actor *actor = [self actorFromJSON:item];
        if (actor)
            [actors addObject:actor];
    }
#if TARGET_OS_IOS //Replace target check with ios to use same class in tv OS
    [[SpotlightStore shared] addActors:actors];
#endif
    return actors.count > 0 ? actors : nil;
}

//! Returns array of backdrops from actor JSON
- (NSArray *)backdropArrayFromActorJSON:(id)json {
    NSMutableArray *backdrops = [NSMutableArray new];
    for (NSDictionary *item in json[@"tagged_images"][@"results"])
        if ([item[@"image_type"] isEqualToString:@"backdrop"] && [item[@"file_path"] length] > 0)
            [backdrops addObject:[Backdrop backdropWithPath:item[@"file_path"]]];
    return backdrops.count > 0 ? backdrops : nil;
}

- (NSArray *)portraitsFromActorJson:(id)json {
    NSArray *items = json[@"images"][@"profiles"];
    return [items arrayByMappingObjectsWithBlock:^(NSDictionary *item){
        return [Portrait portraitWithPath:item[@"file_path"]];
    }];
}

#pragma mark Checkers

//! Check if we got correct list result from tmdb.org
- (BOOL)isListJsonOK:(id)json {
    return json && json[TMDB_KEY_RESULTS] && [json[TMDB_KEY_RESULTS] count] > 0;
}

//! Check if we got correct movie result from tmdb.org
- (BOOL)isMovieJsonOK:(id)json {
    return json && [json isKindOfClass:[NSDictionary class]] && json[@"title"] && json[@"id"];
}

//! Check if we got correct tv show result from tmdb.org
- (BOOL)isShowJsonOK:(id)json {
    return json && [json isKindOfClass:[NSDictionary class]] && json[@"name"] && json[@"id"];
}

//! Check if we got correct actor result from tmdb.org
- (BOOL)isActorJsonOK:(id)json {
    return json && [json isKindOfClass:[NSDictionary class]] && json[@"name"] && json[@"id"];
}

#pragma mark misc

- (NSURL *)urlForEndpoint:(NSString *)endpoint withParameters:(NSDictionary *)parameters {
    NSMutableString *string = [[NSString stringWithFormat:@"%@/%@?api_key=%@", TMDB_BASE_API_URL, endpoint, TMDB_API_KEY] mutableCopy];
    for (NSString *key in [parameters allKeys])
        [string appendFormat:@"&%@=%@", [self escapeString:key], [self escapeString:parameters[key]]];
    return [NSURL URLWithString:string];
}

- (NSString *)escapeString:(NSString *)string {
    return [string stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
}

@end


