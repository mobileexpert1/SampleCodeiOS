//
//  TmdbStore.h
//
//  Created by Lakhwinder Singh on 03/12/14.
//  Copyright (c) 2014 CSSoft. All rights reserved.
//

@import Foundation;
@class AnyPromise, Movie, Show, Actor, Genre, Crew;

/// Types of movies lists from tmdb.org
typedef enum {
    MovieListTypeNowPlaying,
    MovieListTypeUpcoming,
    MovieListTypePopular,
    MovieListTypeTopRated
} MovieListType;

/**
 Store object for interaction with tmdb.org (singleton)
 @note Do not use this object, use MovieStore instead
 */

@interface TmdbStore : NSObject
//! Singleton (shared instance)
+ (instancetype)shared;
/// Array of genres names which should be skipped
@property (strong, nonatomic) NSArray *skipGenres;
//! Asynchronously returns array of movies of given type
- (void)requestMovieListOfType:(MovieListType)type page:(NSUInteger)page withCompletion:(void(^)(NSArray *movies))completion;
//! Asynchronously returns arrya of movies of given genre
- (void)requestMovieListForGenre:(NSString *)tmdbId page:(NSUInteger)page withCompletion:(void(^)(NSArray *movies))completion;
//! Asynchronously returns movies for a given search string
- (void)requestSearchForMovies:(NSString *)query andPage:(NSInteger)page withCompletion:(void(^)(NSArray *movies))completion;
//! Asynchronously returns shows for a given search string
- (void)requestSearchForShows:(NSString *)query andPage:(NSInteger)page withCompletion:(void(^)(NSArray *movies))completion;
//! Asynchronously returns detailed information about the movie with given id
- (void)requestMovieDetailsById:(NSNumber *)tmdbId withCompletion:(void(^)(Movie *movie))completion;
//! Asynchronously returns detailed information about the tv show with given id
- (void)requestShowDetailsById:(NSNumber *)tmdbId withCompletion:(void(^)(Show *show))completion;
//! Asynchronously returns detailed information about the season tv show with given id and season number
- (void)requestShowSeasonDetailsByShow:(Show *)show withCompletion:(void (^)(Show *))completion;
//! Asynchronously returns detailed information about the episode tv show with given id and season number and episode number
- (void)requestShowEpisodeDetailsBySeason:(Show *)season withCompletion:(void (^)(Show *))completion;
//! Asynchronously returns actors for a given search string
- (void)requestSearchForActors:(NSString *)query andPage:(NSInteger)page withCompletion:(void(^)(NSArray *actors))completion;
//! Asynchronously returns array of popular actors
- (void)requestPopularActorsPage:(NSInteger)page withCompletion:(void(^)(NSArray *))completion;
//! Asynchronously returns detailed information about the actor with given id
- (void)requestActorDetailsById:(NSNumber *)tmdbId withCompletion:(void(^)(Actor *actor))completion;

@end


